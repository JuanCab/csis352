#ifndef SQUARE_H
#define SQUARE_H

#include "rectangle.h"

class Square : public Rectangle
{
public:
    Square(double = 0.0, int = 0, int = 0);
};
#endif
